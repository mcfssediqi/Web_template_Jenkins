---
name: Feature request
about: Suggest an idea for this project
title: "[NEW]"
labels: enhancement
assignees: ''

---

## Purpose
> What is it necessary for?

## Expected behavior
Expected the follwing behavior.

## How to deal with this issue
> How do you fix it?

## Notes
