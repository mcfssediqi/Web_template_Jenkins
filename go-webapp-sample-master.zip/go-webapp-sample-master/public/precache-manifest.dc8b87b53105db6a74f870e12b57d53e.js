self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5ffc48740fb393fd88a6",
    "url": "/css/app.750b60b0.css"
  },
  {
    "revision": "3938617ccce9761852ce",
    "url": "/css/chunk-vendors.533831d3.css"
  },
  {
    "revision": "83ab9357d4c1f5a206c0aff3a16cff0b",
    "url": "/index.html"
  },
  {
    "revision": "5ffc48740fb393fd88a6",
    "url": "/js/app.dbc5a974.js"
  },
  {
    "revision": "3938617ccce9761852ce",
    "url": "/js/chunk-vendors.0cedba66.js"
  },
  {
    "revision": "30a1780d264c79567fae09fac31b3072",
    "url": "/manifest.json"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/robots.txt"
  }
]);